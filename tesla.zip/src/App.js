import React from 'react';
import './App.css';

export default class App extends React.Component {
  constructor() {
    super();
    this.state = {
      roadsterData: {}
    };
} 

componentDidMount() {
  const apiUrl = 'https://api.spacexdata.com/v4/roadster';
    
  fetch(apiUrl)
  .then(response => response.json())
  .then(data => {  
    this.setState({roadsterData: data})  
    this.spacekitShow();  
    }) 
  }   

  spacekitShow() {

    const viz = new Spacekit.Simulation(document.getElementById('roadsterMap'), {
      basePath: 'https://typpo.github.io/spacekit/src',
    });    
  
    viz.createStars();    
    viz.createObject('sun', Spacekit.SpaceObjectPresets.SUN);       
    viz.createObject('mercury', Spacekit.SpaceObjectPresets.MERCURY);
    viz.createObject('venus', Spacekit.SpaceObjectPresets.VENUS);
    viz.createObject('earth', Spacekit.SpaceObjectPresets.EARTH);
    viz.createObject('mars', Spacekit.SpaceObjectPresets.MARS);
    viz.createObject('jupiter', Spacekit.SpaceObjectPresets.JUPITER);
    viz.createObject('saturn', Spacekit.SpaceObjectPresets.SATURN);
    viz.createObject('uranus', Spacekit.SpaceObjectPresets.URANUS);
    viz.createObject('neptune', Spacekit.SpaceObjectPresets.NEPTUNE);
    
    const roadster = viz.createObject('spaceman', {
      labelText: 'Tesla Roadster',
      ephem: new Spacekit.Ephem({        
        a: 1.324870564730606E+00,
        e: 2.557785995665682E-01,
        i: 1.077550722804860E+00,             
        om: 3.170946964325638E+02,
        w: 1.774865822248395E+02,
        ma: 1.764302192487955E+02,              
        epoch: 2458426.500000000,
      }, 'deg'),
    });
  }
  
  render () {
    const { roadsterData }  = this.state

    return (
      <article>
        <div className="roadSter">              
          <h2 className="roadster__name">{ roadsterData.name }</h2>
          <p className="roadster__details">{ roadsterData.details }</p>
          <div id="roadsterMap" className="roadster__map"></div>
        </div>
      </article>
    );
  }  
}